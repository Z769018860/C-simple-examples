Common path: /home/user1/tmp
