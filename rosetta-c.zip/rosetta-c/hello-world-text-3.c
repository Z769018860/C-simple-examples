#include<stdio.h>

int main()
{
  printf("\nHello world!");
  return 0;
}
