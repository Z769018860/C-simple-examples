#define MYFLOAT_SIZE (sizeof(myFloats)/sizeof(myFloats[0]))
