#define free_grayimg(IMG) free_img((image)(IMG))
