/* interface */
void print_jpg(image img, int qual);
