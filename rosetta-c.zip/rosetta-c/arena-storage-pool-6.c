Typename *var = alloca(sizeof(Typename));
