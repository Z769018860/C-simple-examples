int i;
void* address_of_i = &i;
