#ifndef HAILSTONE
#define HAILSTONE

long hailstone(long, long**);
void free_sequence(long *);

#endif/*HAILSTONE*/
