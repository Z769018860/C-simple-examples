double* funcToBePassed(long* parameter);

/* ... */

int* outInt;

outInt = myFuncComplex(&funcToBePassed);
