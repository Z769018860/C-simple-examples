#ifdef UNDEFINED
This is not compiled.
#if 0
Nor is this.
#endif
And this still is not compiled.
#endif
