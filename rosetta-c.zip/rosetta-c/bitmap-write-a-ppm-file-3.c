void output_ppm(FILE *fd, image img);
