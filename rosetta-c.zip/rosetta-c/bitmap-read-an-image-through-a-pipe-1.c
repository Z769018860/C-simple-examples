image read_image(const char *name);
