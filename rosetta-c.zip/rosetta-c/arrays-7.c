*(array + index) = 1;
printf("%d\n", *(array + index));
3[array] = 5;
