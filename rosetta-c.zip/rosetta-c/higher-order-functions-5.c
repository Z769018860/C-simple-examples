int* (*funcPointer)( double* (*funcParameter)(long* parameter) );

/* ... */

funcPointer = &myFuncComplex;
