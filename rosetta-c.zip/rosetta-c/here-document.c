#include<stdio.h>

int main()
{
    printf("\nThe Heredoc task was marked not implementable in C.\
    \nFrankly the person who did so seems to have little idea of what C\
    is capable of.\n\
    After all, what would one call this multiline printf statement ?\
    I may be old, but do not forget that it all started with me.\
    \n\nEver enigmatic...\n\
    C   ");

    return 0;
}
