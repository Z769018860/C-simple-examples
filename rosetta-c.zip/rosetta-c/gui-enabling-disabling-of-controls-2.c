#define IDD_DLG                                  101
#define IDC_INPUT                               1001
#define IDC_INCREMENT                           1002
#define IDC_DECREMENT                           1003
#define IDC_QUIT                                1004
