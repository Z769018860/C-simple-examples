// C++ single-line comments were adopted in the C99 standard.
