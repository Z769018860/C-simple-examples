image filter(image img, double *K, int Ks, double, double);
