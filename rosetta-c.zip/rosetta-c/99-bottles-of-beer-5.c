      int b =99,u =1;
     #include<stdio.h>
      char *d[16],y[]
      = "#:ottle/ of"
      ":eer_ a_Go<o5"
      "st>y\x20some6"
      "_Take8;down4p"
      "a=1rou7_17 _<"
      "h;_ m?_nd_ on"
      "_085wal" "l_ "
      "b_e _ t_ss it"
      "_?4bu_ore_9, "
      "\060.""@, 9$";
     # define x  c  ^=
    #include <string.h>
   #define or(t,z) else\
  if(c==t && !(c = 0) &&\
 (c =! z)); int p(char *t)
{ char *s = t; int c; for (
d[c = 0] = y; !t && (d[c +1
]= strchr(s = d[c], '_'));*
(d[++c]++) = 0); for(t = s?
s:t;(c= *s++); c && putchar
(c)) { if (!((( x 48)& ~0xf
) && ( x 48)) ) p(d[c]), c=
0 ; or('$', p(b - 99?".\n":
"." ) && p(b - 99? t : ""))
or ('\x40', c && p( d[!!b--
+ 2])) or('/', c && p( b^1?
"s": "")) or ('\043', b++ ?
p("So6" + --b):!printf("%d"
, b ? --b : (b += 99))) or(
'S',!(++u % 3) * 32+ 78) or
('.', puts("."))}return c;}
 int main() {return p(0);}
