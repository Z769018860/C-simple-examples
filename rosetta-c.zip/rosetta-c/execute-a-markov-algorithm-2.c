Rules from 'rule1' ok
text:     I bought a B of As from T S.
markoved: I bought a bag of apples from my brother.

Rules from 'rule2' ok
text:     I bought a B of As from T S.
markoved: I bought a bag of apples from T shop.

Rules from 'rule3' ok
text:     I bought a B of As W my Bgage from T S.
markoved: I bought a bag of apples with my money from T shop.

Rules from 'rule4' ok
text:     _1111*11111_
markoved: 11111111111111111111

Rules from 'rule5' ok
text:     000000A000000
markoved: 00011H1111000
