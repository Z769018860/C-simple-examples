static union
{
  int i;
  int j;
};
