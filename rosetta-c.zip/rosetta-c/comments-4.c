#if 0
While technically not a comment, this is also ignored by the compiler
#endif
