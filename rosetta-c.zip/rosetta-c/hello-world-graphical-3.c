#include <windows.h>
MessageBox(NULL, _T("Goodbye, World!"), _T("Rosettacode"), MB_OK | MB_ICONINFORMATION);
/* different buttons and icons can be used. please read MS documentation for details. */
