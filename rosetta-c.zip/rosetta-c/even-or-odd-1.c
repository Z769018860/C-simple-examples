if (x & 1) {
    /* x is odd */
} else {
    /* or not */
}
