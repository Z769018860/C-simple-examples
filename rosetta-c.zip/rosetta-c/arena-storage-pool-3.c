typedef struct mytypeStruct { .... } sMyType, *MyType;

MyType var = malloc(sizeof(sMyType));
