main()
{
  return 0;
}
