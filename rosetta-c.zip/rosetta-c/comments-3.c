/* some comment /* trying to nest some other comment */ inside */
