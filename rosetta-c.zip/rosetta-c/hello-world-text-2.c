#include <stdlib.h>
#include <stdio.h>

int main(void)
{
  puts("Hello world!");
  return EXIT_SUCCESS;
}
