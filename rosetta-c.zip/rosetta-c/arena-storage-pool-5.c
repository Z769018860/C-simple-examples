free(var);
