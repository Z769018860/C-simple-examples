#include <stdlib.h>
#include <stdio.h>

int main() {
  puts(getenv("HOME"));
  return 0;
}
