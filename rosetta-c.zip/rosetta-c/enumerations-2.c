typedef enum { apple, banana, cherry } fruits;

typedef enum { apple = 0, banana = 1, cherry = 2 } fruits;
