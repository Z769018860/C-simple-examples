insert(&a, &c);
