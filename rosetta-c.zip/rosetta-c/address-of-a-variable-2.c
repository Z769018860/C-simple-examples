#include <memory>
int i;
auto address_of_i = std::addressof(i);
