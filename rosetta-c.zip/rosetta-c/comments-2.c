struct charisma {};
void f(char/* comment */isma) {}
