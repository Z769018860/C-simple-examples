#include <stdio.h>

int main()
{
        unsigned int i = 0;
        do { printf("%o\n", i++); } while(i);
        return 0;
}
