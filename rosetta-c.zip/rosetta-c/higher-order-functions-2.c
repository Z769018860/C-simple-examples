void funcToBePassed(void);

/* ... */

myFuncSimple(&funcToBePassed);
