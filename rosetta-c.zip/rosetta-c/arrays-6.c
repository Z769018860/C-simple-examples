printf("%d\n", myArray[1]);
