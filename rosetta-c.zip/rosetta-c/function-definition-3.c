x = MULTIPLY(x + z, y);
