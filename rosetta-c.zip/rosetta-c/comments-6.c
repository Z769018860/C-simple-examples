#if 0	
This isn't valid.	
#endif
