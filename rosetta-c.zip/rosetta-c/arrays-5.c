myArray[0] = 1;
myArray[1] = 3;
