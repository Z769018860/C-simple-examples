enum fruits { apple, banana, cherry };

enum fruits { apple = 0, banana = 1, cherry = 2 };
