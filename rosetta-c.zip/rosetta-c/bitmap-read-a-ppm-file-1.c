image get_ppm(FILE *pf);
