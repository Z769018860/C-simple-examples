#include <stdio.h>
const int val = 2*3*4*5*6*7*8*9*10;
int main(void) {
	printf("10! = %d\n", val );
	return 0;
}
