assert(a == 42 && "Error message");
