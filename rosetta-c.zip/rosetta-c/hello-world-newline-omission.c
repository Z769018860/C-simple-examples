#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  (void) printf("Goodbye, World!");    /* No automatic newline */
  return EXIT_SUCCESS;
}
