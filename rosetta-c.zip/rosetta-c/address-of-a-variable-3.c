int& i = *(int*)0xA100;
