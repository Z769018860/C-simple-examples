#define MULTIPLY(X, Y) ((X) * (Y))
