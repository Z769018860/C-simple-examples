int i;
int& j = i;
