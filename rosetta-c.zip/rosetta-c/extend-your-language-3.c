$ make exten && ./exten 3 33 333 3a b " " -2
cc     exten.c   -o exten
3: a number
33: a big number
333: a very big number
3a: not a number
b: not a number
 : not a number
-2: a number
